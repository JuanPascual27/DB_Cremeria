/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manejoBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.table.DefaultTableModel;

public class AdminProductos {
    Connection con;
    Conexion cn = new Conexion();
    
    public void llenarTabla(String sql, DefaultTableModel modelo) {
        try {
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            ResultSet rs = cmd.executeQuery();
            int col = rs.getMetaData().getColumnCount();
            while(rs.next()){
                Object[] datos = new Object[col];
                for(int i = 0; i < col; i++){
                    if(i < 2 || i == 6)
                        datos[i] = rs.getString(i+1);
                    else if(i == 2)
                        datos[i] = rs.getString(5);
                    else if(i == 3)
                        datos[i] = rs.getString(i);
                    else if(i == 4)
                        datos[i] = rs.getString(6);
                    else if(i == 5)
                        datos[i] = "$" + rs.getString(4);
                }
                modelo.addRow(datos);
            }
            cmd.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }  

    public int agregar(String nom, String det, float cant, float precio, String fecha) {
        int band = 0;
        try {
            String id = "Pd" + obtenerFecha();
            id += nextId("select IdProducto from Productos where IdProducto like '%" + id + "%'");
            String sql = "insert into Productos values(?,?,?,?,?,?,?)";
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            cmd.setString(1, id);
            cmd.setString(2, nom);
            cmd.setFloat(3, cant);
            cmd.setFloat(4, precio);
            cmd.setString(5, det);
            cmd.setFloat(6, 0);
            cmd.setString(7, fecha);
            band = cmd.executeUpdate();
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return band;
    }
    
    //buscar esta obsoleto
    /*public Object[] buscar(String sql, int col) {
        Object[] datos = new Object[col];
        for(int i = 0; i < col; i++){
            datos[i] = "";  
        }
        try {
            con = cn.conectar();
            PreparedStatement cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();
            while(rs.next()) {
                for(int i = 0; i < col; i++){
                    datos[i] = rs.getString(i+1);  
                }
            }
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return datos;
    }*/
    
    public int eliminar(String id) {
        int band = 0;
        try {
            String sql = "delete from Productos where IdProducto = ?";
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            cmd.setString(1, id);
            band = cmd.executeUpdate();
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return band;
    }
    
    public int modificar(String id, String nom, String det, float cant, float precio, String fecha) {
        int band = 0;
        try {
            String sql = "update Productos set NombreProducto = ?, CantidadP = ?, Precio = ?, Detalles = ?, FechaCaducidad = ? where IdProducto = ?";
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            cmd.setString(1, nom);
            cmd.setFloat(2, cant);
            cmd.setFloat(3, precio);
            cmd.setString(4, det);
            cmd.setString(5, fecha);
            cmd.setString(6, id);
            band = cmd.executeUpdate();
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return band;
    }
    
    public String nextId(String sql) {
        ArrayList<String> ids = new ArrayList<>();
        int i = 0;
        String r = null;
        try {
            con = cn.conectar();
            PreparedStatement cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();;
            while(rs.next())
                ids.add(rs.getString(1));
            cmd.close();
            con.close();
            for(i = 0; i < ids.size(); i++){
                if(Integer.parseInt(ids.get(i).substring(4)) != i+1)
                    break;
            }
            r = String.format("%04d",i+1);
        } catch (Exception e) {
            System.out.println(e);
        }
        return r;
    }
    
    public String obtenerFecha(){
        String fecha = "";
        java.util.Date date = new java.util.Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dateYear = calendar.get(Calendar.YEAR);
        fecha = Integer.toString(dateYear).substring(2);
        return fecha;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manejoBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tulre
 */
public class AdminProveedores {
    Connection con;
    Conexion cn = new Conexion();
    
    public void llenarTabla(String sql, DefaultTableModel modelo) {
        try {
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            ResultSet rs = cmd.executeQuery();
            int col = rs.getMetaData().getColumnCount();
            while(rs.next()){
                Object[] datos = new Object[col];
                for(int i = 0; i < col; i++){
                    datos[i] = rs.getString(i+1);                  
                }
                modelo.addRow(datos);
            }
            cmd.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public int agregar(String nom) {
        int band = 0;
        try {
            String id = "Pv" + obtenerFecha();
            id += nextId("select IdProveedor from Proveedores where IdProveedor like '%" + id + "%'");
            String sql = "insert into Proveedores values(?,?)";
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            cmd.setString(1, id);
            cmd.setString(2, nom);
            band = cmd.executeUpdate();
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return band;
    }
    
    //buscar esta obsoleto
    /*public Object[] buscar(String sql, int col) {
        Object[] datos = new Object[col];
        for(int i = 0; i < col; i++){
            datos[i] = "";  
        }
        try {
            con = cn.conectar();
            PreparedStatement cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();
            while(rs.next()) {
                for(int i = 0; i < col; i++){
                    datos[i] = rs.getString(i+1);  
                }
            }
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return datos;
    }*/
    
    public int eliminar(String id) {
        int band = 0;
        try {
            String sql = "delete from Proveedores where IdProveedor = ?";
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            cmd.setString(1, id);
            band = cmd.executeUpdate();
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return band;
    }
    
    public int modificar(String id, String nom) {
        int band = 0;
        try {
            String sql = "update Proveedores set NomProveedor = ? where IdProveedor = ?";
            con = cn.conectar();
            CallableStatement cmd = con.prepareCall(sql);
            cmd.setString(1, nom);
            cmd.setString(2, id);
            band = cmd.executeUpdate();
            cmd.close();
            con.close();          
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return band;
    }
    
    public String nextId(String sql) {
        ArrayList<String> ids = new ArrayList<>();
        int i = 0;
        String r = null;
        try {
            con = cn.conectar();
            PreparedStatement cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();;
            while(rs.next())
                ids.add(rs.getString(1));
            cmd.close();
            con.close();
            for(i = 0; i < ids.size(); i++){
                if(Integer.parseInt(ids.get(i).substring(4)) != i+1)
                    break;
            }
            r = String.format("%04d",i+1);
        } catch (Exception e) {
            System.out.println(e);
        }
        return r;
    }
    
    public String obtenerFecha(){
        String fecha = "";
        java.util.Date date = new java.util.Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dateYear = calendar.get(Calendar.YEAR);
        fecha = Integer.toString(dateYear).substring(2);
        return fecha;
    }
}

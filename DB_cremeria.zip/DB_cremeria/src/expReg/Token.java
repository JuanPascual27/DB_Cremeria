/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package expReg;

/**
 *
 * @author tulre
 */
public class Token {
    private Tipos tipo;
   private String valor;
   
   public Tipos getTipo(){
      return tipo;
   }
   
   public void setTipo(Tipos tipo){
      this.tipo = tipo;
   }
   
   public String getValor(){
      return valor;
   }
   
   public void setValor(String valor){
      this.valor = valor;
   }
   
    enum Tipos{
        idVend("^Ve[0-9]{1,6}$"),
        nom("^[A-Z][a-z]+[[ ][A-Z][a-z]+]*$"),
        idProv("^Pv[0-9]{1,6}$"),
        nulo("^$"),
        car("^[A-Z|a-z]$"),
        num("^[0-9]+$"),
        /*ent("^[0]$|^[0-9]+$"),
        ide("^[a-z][[a-z|0-9|A-Z]*[_]{0,1}[a-z|0-9|A-Z]+]*$"),
        bol("^[V|F]$"),
        cod("^[\"]$"),
        fin("^[;]$"),
        esp("^[ ]$"),
        asi("^[=]$"),
        ope("^[+*-]$"),
        agr("^[()]$")*/;

        public final String patron;
        Tipos(String s){
           this.patron = s;
        }
    }
}

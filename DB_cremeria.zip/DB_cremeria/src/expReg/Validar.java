/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package expReg;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import static expReg.Token.Tipos;
/**
 *
 * @author tulre
 */
public class Validar {
    public static String analizador(String lex){
        boolean matched = false;
        Token tk = null;
        String s = null;
        
        for(Token.Tipos tokenTipo: Token.Tipos.values()){
            Pattern patron = Pattern.compile(tokenTipo.patron);
            Matcher matcher = patron.matcher(lex);
            if (matcher.find()){
                tk = new Token();
                tk.setTipo(tokenTipo);
                tk.setValor(lex);
                matched = true;
            }
        }
        //Si el lexema no corresponde a las expresiones regulares no se acepta e informa error lexico
        if(!matched){
            //System.out.println("Error en linea " + nL + ": " + lex + " contiene un caracter indefinido o no es lexicamente correcto");
        }else{
            s = tk.getTipo().toString();
        }
        return s;
    }
    
    public static String validarProductos(String lex){
        boolean matched = false;
        TokenProductos tk = null;
        String s = null;
        
        for(TokenProductos.Tipos tokenTipo: TokenProductos.Tipos.values()){
            Pattern patron = Pattern.compile(tokenTipo.patron);
            Matcher matcher = patron.matcher(lex);
            if (matcher.find()){
                tk = new TokenProductos();
                tk.setTipo(tokenTipo);
                tk.setValor(lex);
                matched = true;
            }
        }
        //Si el lexema no corresponde a las expresiones regulares no se acepta e informa error lexico
        if(!matched){
            //System.out.println("Error en linea " + nL + ": " + lex + " contiene un caracter indefinido o no es lexicamente correcto");
        }else{
            s = tk.getTipo().toString();
        }
        return s;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package expReg;

/**
 *
 * @author tulre
 */
public class TokenProductos {
    private Tipos tipo;
    private String valor;
   
    public Tipos getTipo(){
       return tipo;
    }
   
    public void setTipo(Tipos tipo){
       this.tipo = tipo;
    }

    public String getValor(){
       return valor;
    }

    public void setValor(String valor){
       this.valor = valor;
    }

    enum Tipos{
        idProd("^Pd[0-9]{1,6}$"),
        nom("^[A-Z][a-z]+[ [A-Z][a-z]+]*$"),
        cant("^[0-9]{1,6}(\\.[0-9]{1,3}){0,1}$"),
        prec("^\\$[0-9]{1,6}(\\.[0-9]{1,2}){0,1}$"),
        fecha("^([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{4})|([0-9]{4}[/-][0-9]{1,2}[/-][0-9]{1,2})$"),
        nulo("^$"),;

        public final String patron;
        Tipos(String s){
            this.patron = s;
        }
    }
}

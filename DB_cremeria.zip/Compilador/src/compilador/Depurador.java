/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author tulre
 */
public class Depurador {
    static String rutaReader = "../archivo/Programa1.crystal";
    static String rutaWriter = "../archivo/Programa1.dep";
    static boolean comentario = false;

    public static void inicioDepurar() {
       BufferedReader br = null;
       BufferedWriter bw = null;
       int numLinea = 0;
       boolean escribio = false;
       try {
            String linea, lineaWrite = null;
            br = new BufferedReader(new FileReader(rutaReader));
            bw = new BufferedWriter(new FileWriter(rutaWriter));
            while((linea = br.readLine()) != null){
                numLinea++;
                if(linea.length() != 0){
                    if(escribio){
                        //if(!comentario)//Si el comentario en bloque no salta de linea
                            bw.newLine();
                        escribio = false;
                    }
                    lineaWrite = depurar(linea);
                    if(lineaWrite.length() != 0){
                        bw.write(numLinea + " " + lineaWrite);
                        escribio = true;
                        bw.flush();
                    }
                }
            }
        }catch(IOException e){
            e.printStackTrace();
        }finally{
            try{
                if(br != null)
                    br.close();
                if(bw != null)
                    bw.close();
            }catch(IOException ex){
                ex.printStackTrace();
            }
        }
    }

    // En el lenguaje
    // ** comenta toda una linea
    // *+ comenta un bloque
    public static String depurar(String linea){
        String lineaR = "";
        char c = Character.MIN_VALUE;
        int inicioSub = 0, finalSub = 0;
        boolean primero = true, espacio = false;
        while(finalSub < linea.length()){
            c = linea.charAt(finalSub);
            if(!comentario){
                switch (c){
                    case '*':
                        if(!espacio)
                            lineaR += linea.substring(inicioSub,finalSub);
                        inicioSub = comprobarComentarios(finalSub,linea);
                        if(inicioSub == finalSub)
                            finalSub = inicioSub+1;
                        else
                            finalSub = inicioSub;
                        break;
                    case ' ':
                        if(!espacio)
                            lineaR += linea.substring(inicioSub,finalSub);
                        inicioSub = eliminarEspacios(finalSub,linea);
                        finalSub = inicioSub;
                        if(!primero)
                            espacio = true;
                        break;
                    case '"':
                        if(espacio){
                            espacio = false;
                            lineaR += " ";
                        }
                        finalSub = buscarFinCadena(finalSub,linea);
                        lineaR += linea.substring(inicioSub,finalSub);
                        break;
                    default:
                        if(primero)
                            primero = false;
                        if(espacio){
                            espacio = false;
                            lineaR += " ";
                        }
                        finalSub++;
                        if(finalSub == linea.length())
                            lineaR += linea.substring(inicioSub,finalSub);
                }
            }else{
                inicioSub = buscarFinComen(finalSub-1,linea);
                finalSub = inicioSub;
            }
        }
        return lineaR;
    }

    public static int comprobarComentarios(int chara, String linea){
        chara++;
        if(linea.charAt(chara) == '*'){
            chara = linea.length();
        }else if(linea.charAt(chara) == '+'){
            comentario = true;
            if(chara != linea.length()-1)
                chara = buscarFinComen(chara,linea);
            else
                chara = linea.length();
        }else
            chara--;
        return chara;
    }

    public static int buscarFinComen(int chara, String linea){
        chara++;
        boolean fin = false;
        while(!fin && chara != linea.length()-1){
            if(linea.charAt(chara) == '+'){
                chara++;
                if(linea.charAt(chara) == '*')
                    fin = true;
            }else
                chara++;
        }
        if(fin)
            comentario = false;
        chara++;
        return chara;
    }

    public static int eliminarEspacios(int chara, String linea){
        chara++;
        while(chara != linea.length() && linea.charAt(chara) == ' '){
            chara++;
        }
        return chara;
    }

    public static int buscarFinCadena(int chara, String linea){
        chara++;
        while(chara != linea.length() && linea.charAt(chara) != '"'){
            chara++;
        }
        chara++;
        return chara;
    }
}

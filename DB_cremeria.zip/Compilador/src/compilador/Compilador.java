/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilador;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.function.Consumer;

import static compilador.Token.Tipos;
/**
 *
 * @author tulre
 */
public class Compilador {
    //Archivo depurado
    static String rutaReader = "../archivo/Programa1.dep";
    static String [][] palRes = {{"ent","1"},{"cad","1"},{"bool","1"},{"leer","2"},{"imp","3"}};
    //separadores para StringTokenizer
    static String separadores = "=+*/-()\"{}; ";
    static ArrayList<Simbolo> tabSim = new ArrayList<>(); //Diamond inference de <Simbolo>
    //contsdor de identificadores
    static int contId = 0, estado = 0;
    /*
        valor de estado:
        0 = inicio de linea de codigo
        1 = declaracion de variable
        2 = lectura
        3 = impresion
        4 = espera = para la inicializacion
        5 = inicializacion
        6 = comienzo cadena
        9 = fin de linea;
    */
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader br = null;
        //Depurar el archivo fuente
        Depurador.inicioDepurar();
        try{
            String linea;
            br = new BufferedReader(new FileReader(rutaReader));
            //leer sigueinte linea hasta que no haya otra
            while((linea = br.readLine()) != null){
                if(linea.length() != 0)
                    //mandar linea al analizador sintactico
                    anSint(linea);
            }
        }catch(IOException e){
            //algo
        }finally{
            try{
                if(br != null)
                    br.close();
            }catch(IOException ex){
                //algo
            }
        }
        System.out.println();
        tabSim.forEach(new Consumer<Simbolo>() {
            @Override
            public void accept(Simbolo sim) {
                System.out.println(sim.getSimbolo() + " " + sim.getTipo() + " " + sim.getValor() + " " + sim.getId());
                
            }
        });
    }
    
    //analizador sintactico
    public static void anSint(String linea){
        int nL, x = 0;
        estado = 0;
        //Obtener el numero de linea
        while((linea.charAt(x)) != ' ')
            x++;
        nL = Integer.parseInt(linea.substring(0,x));
        linea = linea.substring(x+1,linea.length());
        //Separar todos las palabras, simbolos y espacios para analizarlos
        StringTokenizer st = new StringTokenizer(linea,separadores,true);
        String lex, cad = "";
        String [] s, s1 = null;
        Token tk;
        Simbolo busqueda1 = null, busqueda2;
        //Hacer el analisis sintactico si aun existen tokens por analizar
        while(st.hasMoreTokens()){
            lex = st.nextToken();
            tk = anLex(nL,lex);
            if(tk != null){
                switch(tk.getTipo().toString()) {
                    case "ide":
                        if(estado == 0){
                            s = buscarRes(tk.getValor());
                            if(s != null){
                                estado = Integer.parseInt(s[1]);
                                s1 = s;
                            }else{
                                busqueda1 = buscarTabla(tk.getValor());
                                if(busqueda1 != null)
                                    estado = 4;
                                else{
                                    estado = 0;
                                    while(st.hasMoreTokens())
                                        st.nextToken();
                                    System.out.println("Error en linea " + nL + ": \"" + tk.getValor() + "\"");
                                }
                            }
                        }else if(estado == 1){
                            s = buscarRes(tk.getValor());
                            if(s == null)
                                if(buscarTabla(tk.getValor()) == null){
                                    estado = 0;
                                    contId++;
                                    tabSim.add(new Simbolo(tk.getValor(),s1[0],"id"+contId));
                                }else{
                                    estado = 0;
                                    System.out.println("Error en linea " + nL + ": El identificador \"" + tk.getValor() + "\" ya a sido declarado");
                                }
                            else{
                                estado = 0;
                                System.out.println("Error en linea " + nL + ": No se puede declarar la palabra reservada \"" + tk.getValor() + "\"");
                            }
                        }else if(estado == 5){
                            s = buscarRes(tk.getValor());
                            if(s == null){
                                busqueda2 = buscarTabla(tk.getValor());
                                if(busqueda2 != null){
                                    if(busqueda2.getTipo().equals(busqueda1.getTipo()))
                                        busqueda1.setValor(busqueda2.getValor());
                                }else
                                    System.out.println("Error en linea " + nL + ": El identificador \"" + tk.getValor() + "\" no existe.");
                            }else{
                                //Notificar error de declaracion de reservada
                            }
                        }else if(estado == 6){
                            cad += lex;
                        }else{
                            estado = 0;
                            while(st.hasMoreTokens())
                                st.nextToken();
                            System.out.println("Error en linea " + nL + ": \"" + tk.getValor() + "\"");
                        }
                        break;
                    case "ent":
                        if(estado == 5){
                            if(busqueda1.getTipo().equals("ent"))
                                busqueda1.setValor(tk.getValor());
                            else{
                                estado = 0;
                                while(st.hasMoreTokens())
                                    st.nextToken();
                                System.out.println("Error en linea " + nL + ": Tipos incompatibles.");
                            }
                        }else if(estado == 6)
                            cad += lex;
                        else{
                            estado = 0;
                            System.out.println("Error en linea " + nL + ": \"" + tk.getValor() + "\"");
                        }
                        break;
                    case "esp":
                        if(estado == 1){
                            
                        }else if(estado == 4){
                            
                        }else if(estado == 5){
                            
                        }else if(estado == 6){
                            cad += lex;
                        }
                        break;
                    case "bol":
                        if(estado == 5){
                            if(busqueda1.getTipo().equals("bool"))
                                busqueda1.setValor(tk.getValor());
                            else{
                                estado = 0;
                                while(st.hasMoreTokens())
                                    st.nextToken();
                                System.out.println("Error en linea " + nL + ": Tipos incompatibles.");
                            }
                        }
                        break;
                    case "cod":
                        if(estado == 5){
                            estado = 6;
                            cad = lex;
                        }else if (estado == 6){
                            estado = 9;
                            cad += lex;
                            if(busqueda1.getTipo().equals("cad"))
                                busqueda1.setValor(cad);
                            else{
                                estado = 0;
                                while(st.hasMoreTokens())
                                    st.nextToken();
                                System.out.println("Error en linea " + nL + ": Tipos incompatibles.");
                            }
                        }else{
                            System.out.println("Error en linea " + nL + ": \"" + tk.getValor() + "\"");
                            while(st.hasMoreTokens())
                                st.nextToken();
                        }
                        break;
                    case "asi":
                        if(estado == 4)
                            estado = 5;
                        else
                            System.out.println("Error en linea " + nL + ": \"" + tk.getValor() + "\"");
                        break;
                    case "ope":
                        if(estado == 6)
                            cad += lex;
                        else
                            System.out.println("Error en linea " + nL + ": \"" + tk.getValor() + "\"");
                        break;
                    default:
                        //informar error lexico
                        System.out.println("Error en linea " + nL + ": \"" + lex + "\" no es valido en la sintaxis");
                        while(st.hasMoreTokens())
                            st.nextToken();
                        break;
                }
            }else{
                if(estado == 6)
                    cad += lex;
                else if(estado == 1){
                    estado = 0;
                    System.out.println("Error en linea " + nL + ": " + lex + " contiene un caracter indefinido o no es lexicamente correcto");
                    while(st.hasMoreTokens())
                        st.nextToken();
                }else{
                    System.out.println("Error en linea " + nL + ": " + lex + " contiene un caracter indefinido o no es lexicamente correcto");
                    while(st.hasMoreTokens())
                        st.nextToken();
                }    
            }
        }
        if(estado == 1){
            System.out.println("Error en linea " + nL + ": Declaracion vacia");
        }else if(estado == 4){
            System.out.println("Error en linea " + nL + ": Uso inexistente para el identificador " + busqueda1.getSimbolo());
        }
    }
    
    //analizador lexico que devuelve un token con valor/simbolo y tipo
    //si es correcto segun nuestras expresiones regulares de la clase Token
    public static Token anLex(int nL, String lex){
        boolean matched = false;
        Token tk = null;
        
        for(Tipos tokenTipo: Tipos.values()){
            Pattern patron = Pattern.compile(tokenTipo.patron);
            Matcher matcher = patron.matcher(lex);
            if (matcher.find()){
                tk = new Token();
                tk.setTipo(tokenTipo);
                tk.setValor(lex);
                matched = true;
            }
        }
        //Si el lexema no corresponde a las expresiones regulares no se acepta e informa error lexico
        if(!matched){}
            //System.out.println("Error en linea " + nL + ": " + lex + " contiene un caracter indefinido o no es lexicamente correcto");
        return tk;
    }
    
    public static String[] buscarRes(String lex){
        String[] res = null;
        for(String [] s: palRes){
            if(lex.equals(s[0])){
                res = s;
                break;
            }
        }
        return res;
    }
    
    public static Simbolo buscarTabla(String s){
        Simbolo sim = null;
        for (int x = 0; x < tabSim.size(); x++) {
            if (tabSim.get(x).getSimbolo().equals(s)){
                sim = tabSim.get(x);
                break;
            }
        }
        return sim;
    }
}
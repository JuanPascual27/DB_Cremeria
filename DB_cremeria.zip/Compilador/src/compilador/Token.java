/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilador;

/**
 *
 * @author tulre
 */
public class Token{
   private Tipos tipo;
   private String valor;
   
   public Tipos getTipo(){
      return tipo;
   }
   
   public void setTipo(Tipos tipo){
      this.tipo = tipo;
   }
   
   public String getValor(){
      return valor;
   }
   
   public void setValor(String valor){
      this.valor = valor;
   }
   
   enum Tipos{
      ent("^[0]$|^[0-9]+$"),
      ide("^[a-z][[a-z|0-9|A-Z]*[_]{0,1}[a-z|0-9|A-Z]+]*$"),
      bol("^[V|F]$"),
      cod("^[\"]$"),
      fin("^[;]$"),
      esp("^[ ]$"),
      asi("^[=]$"),
      ope("^[+*/-]$"),
      agr("^[()]$");
      
      public final String patron;
      Tipos(String s){
         this.patron = s;
      }
   }
}

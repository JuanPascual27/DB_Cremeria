/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compilador;

/**
 *
 * @author tulre
 */
public class Simbolo {
    private String simbolo;
    private String tipo;
    private Object valor;
    private String id;

    public Simbolo(){
        simbolo = null;
        tipo = null;
        valor = 0;
        id = null;
    }
    
    public Simbolo(String s, String t, String i){
        simbolo = s;
        tipo = t;
        if(t.equals("ent"))
            valor = 0;
        else if(t.equals("bool"))
            valor = 'F';
        else
            valor = "";
        id = i;
    }

    public void setSimbolo(String s){
        simbolo = s;
    }

    public void setTipo(String t){
        tipo = t;
    }

    public void setValor(Object v){
        valor = v;
    }

    public void setId(String i){
        id = i;
    }

    public String getSimbolo(){
        return simbolo;
    }

    public String getTipo(){
        return tipo;
    }

    public Object getValor(){
        return valor;
    }

    public String getId(){
        return id;
    }
}
